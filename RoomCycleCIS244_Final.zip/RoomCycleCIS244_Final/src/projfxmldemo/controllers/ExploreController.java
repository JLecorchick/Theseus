package projfxmldemo.controllers;

import java.io.IOException;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import projfxmldemo.helpers.NavigationManager;
import projfxmldemo.AppUtil;
import projfxmldemo.dao.ListingDAO;
import projfxmldemo.models.Listing;

public class ExploreController {
  @FXML private Button listmenuButton;
  @FXML private Button exploremenuButton; 
  @FXML private Button profilemenuButton;
  @FXML private Button btnCancel;
  @FXML private VBox cardsContainer;
  @FXML private Text previouslistingsPlaceholder;
  @FXML private Button addlistingButton;

  @FXML
  public void initialize() {
	  
  // nav bar
  listmenuButton.setOnAction(e ->
      NavigationManager.goTo("ListingPage.fxml", "Your Listings")
  );
  profilemenuButton.setOnAction(e ->
      NavigationManager.goTo("Profile.fxml", "Your Profile")
  );
  
  addlistingButton.setOnAction(e -> {
      Stage filterStage = AppUtil.loadFxml("Filter.fxml", "Filter Listings");
      if (filterStage != null) filterStage.show();
  });

  // load listings
  try {
      List<Listing> listings = ListingDAO.findAll();
      for (Listing l : listings) {
          FXMLLoader loader = new FXMLLoader(
              getClass().getResource("/fxml/Listing_Card_Explore.fxml")
          );
          Node card = loader.load();
          ListingCardExploreController ctrl = loader.getController();
          ctrl.setListing(l);
          cardsContainer.getChildren().add(card);
      }
  } catch (IOException ex) {
      ex.printStackTrace();
  }
  
 // remmove text placeholder when populated
  if (!cardsContainer.getChildren().isEmpty()) {
      previouslistingsPlaceholder.setVisible(false);
      previouslistingsPlaceholder.setManaged(false);
  }
}

// close window on back button
@FXML
private void onBack(ActionEvent evt) {
  ((Stage)btnCancel.getScene().getWindow()).close();
}
}