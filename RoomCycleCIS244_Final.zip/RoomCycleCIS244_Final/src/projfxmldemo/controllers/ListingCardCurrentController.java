package projfxmldemo.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import java.io.File;
import projfxmldemo.dao.ListingImageDAO;
import projfxmldemo.models.Listing;

public class ListingCardCurrentController {

    @FXML private ImageView listingcardImage;
    @FXML private Label titlelistingcardLabel;
    @FXML private Label pricelistingcardLabel;
    @FXML private Label descriptionlistingcardLabel;
    @FXML private Button editlistingcardButton;

    private final ListingImageDAO imgDao = new ListingImageDAO();
    private Listing currentListing;

    @FXML
    public void initialize() {
        // for future: edit button
        editlistingcardButton.setOnAction(evt -> {
        });
    }

    public void setListing(Listing l) {
        this.currentListing = l;
        titlelistingcardLabel.setText(l.getTitle());
        pricelistingcardLabel.setText(String.format("$%.2f", l.getPrice()));
        descriptionlistingcardLabel.setText(l.getDescription());

        // load and fit the image
        String imgPath = imgDao.findImagePathByListingId(l.getListingId());
        File imageFile = (imgPath != null && !imgPath.isBlank()) ? new File(imgPath) : null;

        if (imageFile != null && imageFile.exists()) {
            // use the ImageView's fitWidth/fitHeight settings
            listingcardImage.setImage(new Image(
                imageFile.toURI().toString(),
                listingcardImage.getFitWidth(),
                listingcardImage.getFitHeight(),
                false,   // (preserve original ratio)
                true     // (smooth scaling)
            ));
        } else {
            listingcardImage.setImage(new Image(
                getClass().getResource("/images/placeholder-square.png").toExternalForm(),
                listingcardImage.getFitWidth(),
                listingcardImage.getFitHeight(),
                false,
                true
            ));
        }
    }
}
