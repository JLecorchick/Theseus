package projfxmldemo.controllers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import projfxmldemo.dao.ListingDAO;
import projfxmldemo.dao.ListingImageDAO;
import projfxmldemo.dao.UserDAO;
import projfxmldemo.helpers.CurrentUser;
import projfxmldemo.helpers.NavigationManager;
import projfxmldemo.models.Listing;
import projfxmldemo.models.User;

public class CreateListingController {

    @FXML private Button btnCancel;
    @FXML private Button postButton;
    @FXML private Button imagelistingButton;
    @FXML private TextField titleField;
    @FXML private TextArea descriptionField;
    @FXML private TextField priceField;
    @FXML private Button listmenuButton;
    @FXML private Button exploremenuButton;
    @FXML private Button profilemenuButton;

    private final ListingDAO listingDAO = new ListingDAO();
    private final ListingImageDAO listingImageDAO = new ListingImageDAO();
    private File selectedImageFile;

    @FXML
    public void initialize() {
        // close window on back button click
        btnCancel.setOnAction(evt ->
            ((Stage)btnCancel.getScene().getWindow()).close()
        );

        // nav bar
        listmenuButton.setOnAction(evt ->
            NavigationManager.goTo("/fxml/ListingPage.fxml", "Your Listings")
        );
        exploremenuButton.setOnAction(evt ->
            NavigationManager.goTo("/fxml/Explore.fxml", "Explore")
        );
        profilemenuButton.setOnAction(evt ->
            NavigationManager.goTo("/fxml/Profile.fxml", "Your Profile")
        );

        // image picker
        imagelistingButton.setOnAction(evt -> {
            FileChooser chooser = new FileChooser();
            chooser.setTitle("Choose Listing Image");
            chooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Images", "*.png", "*.jpg", "*.jpeg")
            );
            File f = chooser.showOpenDialog(
                ((Node)evt.getSource()).getScene().getWindow()
            );
            if (f != null) {
                selectedImageFile = f;
            }
        });

        // create listing + input validation checks
        postButton.setOnAction(evt -> {
            String title = titleField.getText().trim();
            String description = descriptionField.getText().trim();
            String priceText = priceField.getText().trim();

            if (title.isEmpty() || description.isEmpty() || priceText.isEmpty()) {
                new Alert(Alert.AlertType.WARNING, "Title, description, and price fields are required.", ButtonType.OK)
                    .showAndWait();
                return;
            }

            double price;
            try {
                price = Double.parseDouble(priceText);
            } catch (NumberFormatException ex) {
                new Alert(Alert.AlertType.ERROR, "Price must be a valid number.", ButtonType.OK)
                    .showAndWait();
                return;
            }

            // look up the current user
            String currentUsername = CurrentUser.getUsername();
            User u = new UserDAO().findByUsername(currentUsername);

            // build and save the listing + check
            Listing listing = new Listing();
            listing.setTitle(title);
            listing.setDescription(description);
            listing.setPrice(price);
            listing.setCreatedBy(currentUsername);
            listing.setUserId(u.getUserId());

            boolean saved = listingDAO.create(listing);
            if (!saved) {
                new Alert(Alert.AlertType.ERROR, "Failed to save listing.", ButtonType.OK)
                    .showAndWait();
                return;
            }

            int listingId = listingDAO.getLatestListingIdForUser(u.getUserId());

            // if an image was added, add to file folder then db
            if (selectedImageFile != null) {
                try {
                    String name = selectedImageFile.getName();
                    String ext  = name.substring(name.lastIndexOf('.'));
                    Path base   = Paths.get(System.getProperty("user.home"),
                                            "Documents",
                                            "RoomCycleImages");
                    Path dest   = base.resolve("listing_" + listingId + ext);

                    Files.createDirectories(base);
                    Files.copy(selectedImageFile.toPath(),
                               dest,
                               StandardCopyOption.REPLACE_EXISTING);

                    if (!listingImageDAO.saveImage(listingId, dest.toString())) {
                        throw new IOException("DB insert failed");
                    }

                    System.out.println("Image saved for listing ID "
                                       + listingId + ": " + dest);

                } catch (IOException ex) {
                    new Alert(Alert.AlertType.ERROR,
                              "Couldn’t save image: " + ex.getMessage(),
                              ButtonType.OK)
                        .showAndWait();
                    return;
                }
            }


            // on success, reopen the list page and close this one
            NavigationManager.goTo("/fxml/ListingPage.fxml", "Your Listings");
            ((Stage)postButton.getScene().getWindow()).close();
        });
    }
}
