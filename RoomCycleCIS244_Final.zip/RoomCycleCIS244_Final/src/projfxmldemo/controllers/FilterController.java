package projfxmldemo.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import projfxmldemo.helpers.NavigationManager;

public class FilterController {

    @FXML private ComboBox<String> categoryCombo;
    @FXML private ComboBox<String> itemTypeCombo;
    @FXML private TextField minPriceField;
    @FXML private TextField maxPriceField;
    @FXML private Button applyFilterButton;
    @FXML private Button cancelButton;

    public void initialize() {
        cancelButton.setOnAction(evt -> {
            Stage stage = (Stage) cancelButton.getScene().getWindow();
            stage.close();
        });
        
    }
}
        