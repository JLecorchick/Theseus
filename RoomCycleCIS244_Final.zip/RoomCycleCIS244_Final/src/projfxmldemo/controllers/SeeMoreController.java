package projfxmldemo.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import projfxmldemo.models.Listing;
import projfxmldemo.models.User;
import projfxmldemo.dao.ListingImageDAO;
import projfxmldemo.dao.UserDAO;
import projfxmldemo.helpers.NavigationManager;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class SeeMoreController {
    @FXML private Button listingsbackButton;
    @FXML private Button listmenuButton;
    @FXML private Button exploremenuButton;
    @FXML private Button profilemenuButton;
    @FXML private Label itemtitleseemorepagelabel;
    @FXML private Label priceseemorepageLabel;
    @FXML private Label phonenumseemorepageLabel;
    @FXML private Button nextpicButton;
    @FXML private ImageView seemorepageImage;
    @FXML private Text seemorepageDescription;

    private final ListingImageDAO imgDao = new ListingImageDAO();
    private List<String> imagePaths;
    private int currentImageIndex = 0;
    private Listing currentListing;

    @FXML
    public void initialize() {
    	
    	// button navs
        listingsbackButton.setOnAction(evt -> {
            NavigationManager.goTo("Explore.fxml", "Explore");
            Stage s = (Stage) listingsbackButton.getScene().getWindow();
            s.close();
        });

        listmenuButton.setOnAction(evt -> {
            NavigationManager.goTo("ListingPage.fxml", "List");
            Stage s = (Stage) listmenuButton.getScene().getWindow();
            s.close();
        });

        exploremenuButton.setOnAction(evt -> {
            NavigationManager.goTo("Explore.fxml", "Explore");
            Stage s = (Stage) exploremenuButton.getScene().getWindow();
            s.close();
        });

        profilemenuButton.setOnAction(evt -> {
            NavigationManager.goTo("Profile.fxml", "Profile");
            Stage s = (Stage) profilemenuButton.getScene().getWindow();
            s.close();
        });

        nextpicButton.setOnAction(evt -> {
            if (imagePaths != null && !imagePaths.isEmpty()) {
                int nextIndex = (currentImageIndex + 1) % imagePaths.size();
                setImage(nextIndex);
            }
        });
    }

    // populate listing with given info 
    public void setListing(Listing listing) {
        this.currentListing = listing;
        itemtitleseemorepagelabel.setText(listing.getTitle());
        priceseemorepageLabel.setText(String.format("$%.2f | ", listing.getPrice()));
        seemorepageDescription.setText(listing.getDescription());
        User seller = new UserDAO().findByUserId(listing.getUserId());
        phonenumseemorepageLabel.setText(seller.getFormattedPhoneNum());

        // initialize image list 
        imagePaths = new ArrayList<>();
        String path = imgDao.findImagePathByListingId(listing.getListingId());
        if (path != null && !path.isBlank()) {
            imagePaths.add(path);
            setImage(0);
        } 

        }
    

    // display image
    private void setImage(int index) {
        this.currentImageIndex = index;
        String imgPath = imagePaths.get(index);
        seemorepageImage.setImage(
            new Image(new File(imgPath).toURI().toString())
        );
    }
}

