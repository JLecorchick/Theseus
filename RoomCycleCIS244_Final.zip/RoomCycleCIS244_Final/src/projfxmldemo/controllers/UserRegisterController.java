package projfxmldemo.controllers;

import java.util.Optional;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import projfxmldemo.AppUtil;
import projfxmldemo.dao.InviteCodeDAO;
import projfxmldemo.dao.UserDAO;
import projfxmldemo.models.User;

public class UserRegisterController {

    @FXML private TextField tfEmail;
    @FXML private TextField tfUsername;
    @FXML private TextField tfAptName;
    @FXML private TextField tfPhone;
    @FXML private PasswordField pfPassword;
    @FXML private Button bnRegister;
    @FXML private Button btnCancel;
    @FXML private CheckBox cbAgree;
    @FXML private Label lbMessage;
    @FXML private Hyperlink termsLink; 

    private final UserDAO userDAO = new UserDAO();
    private final InviteCodeDAO codeDAO = new InviteCodeDAO();
    
    @FXML
    private void onShowTerms(ActionEvent ev) {
    	
    	// terms and conditions
        Alert terms = new Alert(Alert.AlertType.INFORMATION);
        terms.setTitle("Terms & Conditions");
        terms.setHeaderText("Please read carefully:");
        terms.setContentText(
            "1. Who can use RoomCycle\n"
            + "• You must be 18+.\n"
            + "\n"
            + "2. Your account\n"
            + "• You pick a unique username and password; keep them secret.\n"
            + "• You’re responsible for activity on your account.\n"
            + "\n"
            + "3. What you can do\n"
            + "• Buy, sell or swap furniture/items within your apartment complex.\n"
            + "• Message other users to arrange exchanges.\n"
            + "\n"
            + "4. What you must not do\n"
            + "• Don’t post illegal, dangerous or hateful content.\n"
            + "• Don’t spam, scam, or impersonate anyone.\n"
            + "• Don’t share private info (yours or others’).\n"
            + "\n"
            + "5. Privacy & data\n"
            + "• We store only what’s needed to run RoomCycle (username, apartment, phone).\n"
            + "• We won’t sell your data.\n"
            + "\n"
            + "6. Disclaimers & liability\n"
            + "• We provide RoomCycle “as is.” We’re not liable for items you buy/sell.\n"
            + "• Use common sense when meeting up or exchanging goods.\n"
            + "\n"
            + "7. Updates & termination\n"
            + "• We may update these rules—continued use means you accept changes.\n"
            + "• We can suspend or delete accounts that break the rules.\n"
            + "\n"
            + "By checking “I agree,” you confirm you’ve read and accept these simple Terms & Conditions."
        );
        
        terms.initModality(Modality.APPLICATION_MODAL);
        terms.showAndWait();
    }
    
    @FXML
    private void onSignup(ActionEvent evt) {
        String email = tfEmail.getText().trim();
        String user = tfUsername.getText().trim();
        String apt = tfAptName.getText().trim();
        String phone = tfPhone.getText().trim();
        String pass = pfPassword.getText();

        System.out.printf("DEBUG signup fields: code='%s', user='%s', apt='%s', phone='%s'%n",
                tfEmail.getText(),
                tfUsername.getText(),
                tfAptName.getText(),
                tfPhone.getText());
        
        // registration checks
        if (email.isEmpty() || user.isEmpty() || apt.isEmpty() || phone.isEmpty() || pass.isEmpty()) {
            AppUtil.showAlert("All fields are required.", "Error", null);
            return;
            
        }
        
        if (!email.matches(".+@.+\\..+")) {
          lbMessage.setText("Enter a valid email.");
          return;
        }
    
        if (!cbAgree.isSelected()) {
            lbMessage.setText("You must agree to the Terms & Conditions to register.");
            return;
        }

        // creates user 
        User u = new User();
        u.setEmail(email);
        u.setUsername(user);
        u.setAptName(apt);
        u.setPhoneNum(phone);

        if (userDAO.create(u, pass)) {
            codeDAO.markUsed(email);
            AppUtil.showAlert("Please login to complete the 2FA process", "Success", null);
            ((Stage)bnRegister.getScene().getWindow()).close();
        } else {
            AppUtil.showAlert("Registration failed—please enter a valid username / email / phone number", "Error", null);
        }
        
    }

    @FXML
    private void onBack(ActionEvent evt) {
        ((Stage)btnCancel.getScene().getWindow()).close();
    }
    
}
