package projfxmldemo.controllers;

import java.io.IOException;
import java.util.List;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.text.Text;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import projfxmldemo.AppUtil;
import projfxmldemo.dao.ListingDAO;
import projfxmldemo.helpers.CurrentUser;
import projfxmldemo.helpers.NavigationManager;
import projfxmldemo.models.Listing;

public class ListingPageController {
    @FXML private VBox currentlistingvbox;
    @FXML private Text currentlistingsPlaceholder;
    @FXML private Button listmenuButton;
    @FXML private Button exploremenuButton;
    @FXML private Button profilemenuButton;
    @FXML private Button btnCancel;
    @FXML private Button addlistingButton;

    @FXML
    public void initialize() {
        // add new listing dialog
        addlistingButton.setOnAction(evt -> AppUtil.loadFxml("/fxml/Create_Listing.fxml", "Create Listing").show());

        // nav bar
        btnCancel.setOnAction(evt -> ((Stage)btnCancel.getScene().getWindow()).close());
        listmenuButton.setOnAction(evt -> NavigationManager.goTo("/fxml/ListingPage.fxml", "Your Listings"));
        exploremenuButton.setOnAction(evt -> NavigationManager.goTo("/fxml/Explore.fxml", "Explore"));
        profilemenuButton.setOnAction(evt -> NavigationManager.goTo("/fxml/Profile.fxml", "Your Profile"));

        populateCurrentListings();
    }

    // grabs all listings
    private void populateCurrentListings() {
        int me = CurrentUser.getUserId();
        List<Listing> mine = ListingDAO.findAll().stream()
            .filter(l -> l.getUserId() == me)
            .toList();

        if (mine.isEmpty()) {
            currentlistingsPlaceholder.setVisible(true);
            currentlistingsPlaceholder.setManaged(true);
        } else {
            currentlistingsPlaceholder.setVisible(false);
            currentlistingsPlaceholder.setManaged(false);
            for (Listing l : mine) {
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Listing_Card_Current.fxml"));
                    Parent card = loader.load();
                    ListingCardCurrentController ctrl = loader.getController();
                    ctrl.setListing(l);
                    card.maxWidth(Double.MAX_VALUE);
                    currentlistingvbox.getChildren().add(card);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
}