package projfxmldemo.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import projfxmldemo.AppUtil;
import projfxmldemo.dao.UserDAO;
import projfxmldemo.helpers.CurrentUser;
import projfxmldemo.helpers.NavigationManager;
import projfxmldemo.models.User;
import projfxmldemo.helpers.OtpHelper;  

import java.util.Optional;

public class LoginController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Button loginButton;
    @FXML private Hyperlink signupLink;
    @FXML private Label lbMessage;
    @FXML private TextField tfEmail;
    

    private final UserDAO userDAO = new UserDAO();

    @FXML
    public void initialize() {
        loginButton.setOnAction(evt -> handleLogin());
        signupLink.setOnAction(evt ->
            NavigationManager.goTo("/fxml/Signup.fxml", "Sign Up")
        );
    }

    private void handleLogin() {
    	// read user inputs
        String u = usernameField.getText().trim();
        String p = passwordField.getText();

        // checks if username or password are empty
        if (u.isEmpty() || p.isEmpty()) {
            lbMessage.setText("Username & password required.");
            return;
        }

        // calls validatelogin
        if (!userDAO.validateLogin(u, p)) {
            lbMessage.setText("Invalid credentials.");
            return;
        }

        // retrieve user record
        User user = userDAO.findByUsername(u);

        // if it's a user's first login go through 2fa process
        if (user.isFirstLogin()) {
            // send code
            OtpHelper.send(user.getEmail());

            // ask for code back
            TextInputDialog otpDialog = new TextInputDialog();
            otpDialog.setTitle("Two-Factor Authentication");
            otpDialog.setHeaderText("Enter the code we just emailed you");
            otpDialog.setContentText("Code:");
            Optional<String> maybeCode = otpDialog.showAndWait();

            // checks if code was provided or incorrect
            if (maybeCode.isEmpty() 
             || !OtpHelper.validate(user.getEmail(), maybeCode.get().trim())) {
                lbMessage.setText("Invalid or missing 2FA code.");
                return;
            }

            // records if 2fa passed so won't ask again
            userDAO.markNotFirstLogin(user.getUserId());
        }

        // saves user so controllers know who's logged in
        CurrentUser.setUsername(u);
        CurrentUser.setUserId(user.getUserId()); 
        NavigationManager.goTo("/fxml/Explore.fxml", "Explore");
        ((Stage)loginButton.getScene().getWindow()).close();
    }
}

