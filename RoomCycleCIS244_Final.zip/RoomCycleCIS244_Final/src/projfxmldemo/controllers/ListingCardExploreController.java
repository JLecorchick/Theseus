package projfxmldemo.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import projfxmldemo.models.Listing;
import projfxmldemo.dao.ListingImageDAO;
import projfxmldemo.controllers.SeeMoreController;
import projfxmldemo.dao.ListingImageDAO;

public class ListingCardExploreController {
    @FXML private Label titlelistingcardLabel;
    @FXML private Label pricelistingcardLabel;
    @FXML private Label  descriptionlistingcardLabel;
    @FXML private ImageView listingcardImage;  
    @FXML private Button seemorelistingcardButton;

    private final ListingImageDAO imgDao = new ListingImageDAO();
    private Listing currentListing;

    @FXML
    public void initialize() {
        seemorelistingcardButton.setOnAction(evt -> openSeeMore());
    }

    // updates card with listing info
    public void setListing(Listing l) {
        this.currentListing = l;
        titlelistingcardLabel.setText(l.getTitle());
        pricelistingcardLabel.setText(String.format("$%.2f", l.getPrice()));
        descriptionlistingcardLabel.setText(l.getDescription());

        String imgPath = imgDao.findImagePathByListingId(l.getListingId());
	    File imageFile = (imgPath != null && !imgPath.isBlank())
	         ? new File(imgPath)
	         : null;
	
	     if (imageFile != null && imageFile.exists()) {
	         listingcardImage.setImage(new Image(imageFile.toURI().toString()));
	     } else {
	         listingcardImage.setImage(new Image(
	             getClass().getResource("/images/placeholder-square.png")
	                  .toExternalForm()));
	     }
	    }


    // opens see more page and passes in listing obj
    private void openSeeMore() {
        try {
            URL fxmlUrl = getClass().getResource("/fxml/SeeMorePage.fxml");
            if (fxmlUrl == null) {
                System.err.println("FXML not found: fxml/SeeMorePage.fxml");
                return;
            }
            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Parent root = loader.load();

            SeeMoreController ctrl = loader.getController();
            ctrl.setListing(currentListing);

            Stage stage = new Stage();
            stage.setTitle("Details");
            stage.setScene(new Scene(root));
            stage.show();

            Stage me = (Stage) seemorelistingcardButton.getScene().getWindow();
            me.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

