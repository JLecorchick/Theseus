
package projfxmldemo.dao;

import projhelper.DbHelper;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class ListingImageDAO {
    private final DbHelper db = new DbHelper();

// inserts row into ListingimageDAO
    public boolean saveImage(int listingId, String path) {
        String sql = "INSERT INTO listing_images(listing_id, image_path) VALUES(?, ?)";
        try (Connection c = db.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, listingId);
            ps.setString(2, path);
            return ps.executeUpdate() == 1;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

// locate image
    public String findImagePathByListingId(int listingId) {
        String sql = """
            SELECT image_path
              FROM listing_images
             WHERE listing_id = ?
          ORDER BY image_id DESC
             LIMIT 1
        """;
        try (Connection c = db.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, listingId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("image_path");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
}
