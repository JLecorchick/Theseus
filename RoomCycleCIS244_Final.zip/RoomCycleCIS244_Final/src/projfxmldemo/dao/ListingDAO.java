package projfxmldemo.dao;


import projhelper.DbHelper;
import projfxmldemo.models.Listing;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ListingDAO {
    private final DbHelper db = new DbHelper();

    
    // inserts new row into listings table
    public boolean create(Listing listing) {
        String sql = "INSERT INTO listings (title, description, price, category, item_type, color, user_id) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = db.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, listing.getTitle());
            stmt.setString(2, listing.getDescription());
            stmt.setDouble(3, listing.getPrice());
            stmt.setString(4, listing.getCategory());
            stmt.setString(5, listing.getItemType());
            stmt.setString(6, listing.getColor());
            stmt.setInt(7, listing.getUserId());

            return stmt.executeUpdate() == 1;
        } catch (SQLException ex) {
            System.err.println("Error inserting listing: " + ex.getMessage());
            return false;
        }
    }
    
    // loads all rows from listings
    public static List<Listing> findAll() {
        List<Listing> listings = new ArrayList<>();
        DbHelper helper = new DbHelper();
        
        String sql = "SELECT * FROM listings";
        try (Connection conn = helper.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Listing l = new Listing();
                l.setListingId(rs.getInt("listing_id"));
                l.setUserId(rs.getInt("user_id") );
                l.setTitle(rs.getString("title") );
                l.setDescription(rs.getString("description") );
                l.setPrice(rs.getDouble("price") );
                l.setCategory(rs.getString("category") );
                l.setItemType(rs.getString("item_type") );
                l.setColor(rs.getString("color") );
                l.setUserId(rs.getInt("user_id") );
                listings.add(l);
            }
        } catch (SQLException ex) {
            System.err.println("Error loading listings: " + ex.getMessage());
        }
        
        return listings;
    }
    
    public int getLatestListingIdForUser(int userId) {
        try (Connection conn = db.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "SELECT listing_id FROM listings WHERE user_id = ? ORDER BY listing_id DESC LIMIT 1"
             )) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("listing_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }


}