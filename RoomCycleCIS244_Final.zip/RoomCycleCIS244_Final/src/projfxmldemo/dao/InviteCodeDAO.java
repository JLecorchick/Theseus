package projfxmldemo.dao;

import projhelper.DbHelper;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class InviteCodeDAO {
    private final DbHelper db = new DbHelper();

    public boolean validateCode(String code, String aptName) {
        return true;
    }

    public boolean markUsed(String code) {
        return true;

	}
}
