package projfxmldemo.dao;

import projhelper.DbHelper;
import projfxmldemo.models.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class UserDAO {
    private final DbHelper db = new DbHelper();

    // validates username and password by hashing and comparing to table
    public boolean validateLogin(String username, String rawPassword) {
        try (Connection conn = db.getConnection()) {
            String sql = "SELECT password FROM users WHERE username = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String storedHash = rs.getString("password");
                String candidateHash = projhelper.ProjUtil.getSHA(rawPassword);
                return storedHash.equals(candidateHash);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // gets user record via username
    public User findByUsername(String username) {
        User u = null;
        try (Connection conn = db.getConnection()) {
            String sql = "SELECT * FROM users WHERE username = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                u = new User();
                u.setUserId(rs.getInt("user_id"));
                u.setUsername(rs.getString("username"));
                u.setFirstLogin( rs.getBoolean("first_login") );
                u.setPhoneNum(rs.getString("phone_num"));
                u.setAptName(rs.getString("apt_name"));
                u.setAptNum(rs.getString("apt_num"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return u;
    }


    // gets user record via user id
    public User findByUserId(int userId) {
        User u = null;
        try (Connection conn = db.getConnection()) {
            String sql = "SELECT * FROM users WHERE user_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                u = new User();
                u.setUserId(rs.getInt("user_id"));
                u.setUsername(rs.getString("username"));
                u.setFirstLogin(rs.getBoolean("first_login"));
                u.setPhoneNum(rs.getString("phone_num"));
                u.setAptName(rs.getString("apt_name"));
                u.setAptNum(rs.getString("apt_num"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return u;
    }

    // creates new user
    public boolean create(User u, String rawPassword) {
        try (Connection conn = db.getConnection()) {
            String sql = "INSERT INTO users"
                       + " (username, password, phone_num, apt_name, apt_num, email)"
                       + " VALUES (?,?,?,?,?,?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, u.getUsername());
            ps.setString(2, projhelper.ProjUtil.getSHA(rawPassword));
            ps.setString(3, u.getPhoneNum());
            ps.setString(4, u.getAptName());
            ps.setString(5, u.getAptNum());
            ps.setString(6, u.getEmail());
            return ps.executeUpdate() == 1;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // updates firet login to false after user completes 2fa
    public boolean markNotFirstLogin(int userId) {
        String sql = "UPDATE users SET first_login = FALSE WHERE user_id = ?";
        try (Connection conn = new DbHelper().getConnection();
             PreparedStatement p = conn.prepareStatement(sql)) {
            p.setInt(1, userId);
            return p.executeUpdate() == 1;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
   

	public void updatePassword(Object userId, String text) {
		// to do for profile page
		
	}

	public boolean update(User user) {
        String sql = "UPDATE users SET username = ?, apt_name = ?, phone_num = ? WHERE user_id = ?";
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getAptName());
            ps.setString(3, user.getPhoneNum());
            ps.setInt(4, user.getUserId());
            return ps.executeUpdate() == 1;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
		
	}

}
