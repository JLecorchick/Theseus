// represents a row in user in user table

package projfxmldemo.models;

public class User {
    private int userId;
    private String username;
    private String phoneNum;
    private String aptName;
    private String aptNum;
    private String email;
    private boolean firstLogin = true;


    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }

    public String getPhoneNum() {
        return phoneNum;
    }
    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public String getAptName() {
        return aptName;
    }
    public void setAptName(String aptName) {
        this.aptName = aptName;
    }

    public String getAptNum() {
        return aptNum;
    }
    public void setAptNum(String aptNum) {
        this.aptNum = aptNum;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
}
    public boolean isFirstLogin() {
        return firstLogin;
    }
    public void setFirstLogin(boolean firstLogin) {
        this.firstLogin = firstLogin;
    }
    
    public String getFormattedPhoneNum() {
        if (phoneNum != null && phoneNum.length() == 10 && phoneNum.matches("\\d+")) {
            return phoneNum.replaceFirst("(\\d{3})(\\d{3})(\\d{4})", "$1-$2-$3");
        }
        return phoneNum;
    }


}
