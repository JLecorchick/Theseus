// represents a row in listing images table

package projfxmldemo.models;

public class ListingImage {
    private int imageId;
    private int listingId;
    private String imagePath;

    public ListingImage() {
    }

    public ListingImage(int imageId, int listingId, String imagePath) {
        this.imageId = imageId;
        this.listingId = listingId;
        this.imagePath = imagePath;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    public int getListingId() {
        return listingId;
    }

    public void setListingId(int listingId) {
        this.listingId = listingId;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    @Override
    public String toString() {
        return "ListingImage{" +
               "imageId=" + imageId +
               ", listingId=" + listingId +
               ", imagePath='" + imagePath + '\'' +
               '}';
    }
}
