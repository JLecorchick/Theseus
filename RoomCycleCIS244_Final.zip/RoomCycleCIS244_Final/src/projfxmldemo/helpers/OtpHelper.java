package projfxmldemo.helpers;

 
import javafx.scene.control.Alert;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class OtpHelper {
	
	// keeps track of which code was generated for which email address 
    private static final Map<String,String> otpStore = new HashMap<>();
    private static final Random rand = new Random();

    public static void send(String email) {
        // generates 6 digit code and stores for user
        String code = String.format("%06d", rand.nextInt(1_000_000));
        otpStore.put(email, code);

        // mock email 
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("New Email");
        a.setHeaderText("Use this code to finish logging in:");
        a.setContentText(code);
        a.showAndWait();
    }

    // checks for code match 
    public static boolean validate(String email, String enteredCode) {
        String expected = otpStore.get(email);
        if (expected != null && expected.equals(enteredCode)) {
            otpStore.remove(email);
            return true;
        }
        return false;
    }
}


