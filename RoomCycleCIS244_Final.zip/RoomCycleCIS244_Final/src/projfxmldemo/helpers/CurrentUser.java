// answer's: who is logged in?

package projfxmldemo.helpers;

public class CurrentUser {
    private static String username;
    private static int userId;
    public static String getUsername() { return username; }
    public static void setUsername(String u) { username = u; }
    public static int getUserId() { return userId;}
    public static void setUserId(int id) { userId = id;
}
}